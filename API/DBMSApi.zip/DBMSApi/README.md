﻿# DBMS Project Notes
Add migration using 
PM> EntityFrameworkCore\Create-Migration migrationname
PM> EntityFrameworkCore\Update-Database

## Note for future use
need SQLitePCLRaw.bundle_e_sqlite3 installed for some reason