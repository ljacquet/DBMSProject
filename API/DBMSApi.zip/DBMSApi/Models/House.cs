﻿namespace DBMSApi.Models
{
    public class House
    {
        public int houseId { get; set; }
        public string houseName { get; set; }
        public int ownerId { get; set; }
    }
}